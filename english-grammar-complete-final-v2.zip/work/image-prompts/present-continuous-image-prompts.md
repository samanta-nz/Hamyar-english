# پرامپت‌های تصویر داستان — Present Continuous

## شخصیت ثابت

Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration.

## سبک و محدودیت مشترک

تصویرسازی کتاب کودک امروزی، نرم و طبیعی، قاب افقی ۴:۳، بدون متن، عدد، حروف، زیرنویس، لوگو، رابط کاربری یا حباب گفت‌وگو. فقط یک لحظهٔ مشخص را نشان بده؛ از ترکیب چند زمان یا چند قاب در یک تصویر پرهیز کن. سارا در همهٔ صحنه‌ها همان چهره، سن، مو و لباس مرجع را دارد.

## صحنهٔ ۱ — نقاشی در کلاس

**جملهٔ دقیق داستان:**
> Right now, Sara is painting a large blue tree for the school art show.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Continuous”. Show exactly one instant: Right now, Sara is painting a large blue tree for the school art show. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۲ — ترکیب رنگ‌ها

**جملهٔ دقیق داستان:**
> Her friend Noah is mixing green paint beside her.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Continuous”. Show exactly one instant: Her friend Noah is mixing green paint beside her. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۳ — آماده‌کردن نمایشگاه

**جملهٔ دقیق داستان:**
> A teacher is hanging the finished pictures along the hall.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Continuous”. Show exactly one instant: A teacher is hanging the finished pictures along the hall. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۴ — یادگیری این هفته

**جملهٔ دقیق داستان:**
> This week, Sara is learning how to use watercolors.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Continuous”. Show exactly one instant: This week, Sara is learning how to use watercolors. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۵ — قرار برای آینده

**جملهٔ دقیق داستان:**
> They are meeting their families at the gallery at six tonight.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Continuous”. Show exactly one instant: They are meeting their families at the gallery at six tonight. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۶ — صدای کلاس

**جملهٔ دقیق داستان:**
> Listen! The students are laughing as the doors are opening.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Continuous”. Show exactly one instant: Listen! The students are laughing as the doors are opening. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.
