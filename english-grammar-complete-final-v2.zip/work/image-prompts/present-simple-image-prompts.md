# پرامپت‌های تصویر داستان — Present Simple

## شخصیت ثابت

Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration.

## سبک و محدودیت مشترک

تصویرسازی کتاب کودک امروزی، نرم و طبیعی، قاب افقی ۴:۳، بدون متن، عدد، حروف، زیرنویس، لوگو، رابط کاربری یا حباب گفت‌وگو. فقط یک لحظهٔ مشخص را نشان بده؛ از ترکیب چند زمان یا چند قاب در یک تصویر پرهیز کن. سارا در همهٔ صحنه‌ها همان چهره، سن، مو و لباس مرجع را دارد.

## صحنهٔ ۱ — شروع روز

**جملهٔ دقیق داستان:**
> Every Saturday, Sara starts her day at seven.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Simple”. Show exactly one instant: Every Saturday, Sara starts her day at seven. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۲ — صبحانهٔ خانوادگی

**جملهٔ دقیق داستان:**
> She eats breakfast with her younger brother, Adam.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Simple”. Show exactly one instant: She eats breakfast with her younger brother, Adam. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۳ — راه مدرسه

**جملهٔ دقیق داستان:**
> She takes the bus to the school library.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Simple”. Show exactly one instant: She takes the bus to the school library. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۴ — کمک به دانش‌آموز تازه

**جملهٔ دقیق داستان:**
> At ten, she helps a new student find the science books.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Simple”. Show exactly one instant: At ten, she helps a new student find the science books. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۵ — تماس با مادر

**جملهٔ دقیق داستان:**
> At noon, Sara calls her mother from the garden.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Simple”. Show exactly one instant: At noon, Sara calls her mother from the garden. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۶ — پایان روز

**جملهٔ دقیق داستان:**
> She returns home before sunset and writes in her notebook.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Simple”. Show exactly one instant: She returns home before sunset and writes in her notebook. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.
