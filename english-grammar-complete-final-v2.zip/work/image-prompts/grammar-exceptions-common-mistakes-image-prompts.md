# پرامپت‌های تصویر داستان — Grammar Exceptions

## شخصیت ثابت

Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration.

## سبک و محدودیت مشترک

تصویرسازی کتاب کودک امروزی، نرم و طبیعی، قاب افقی ۴:۳، بدون متن، عدد، حروف، زیرنویس، لوگو، رابط کاربری یا حباب گفت‌وگو. فقط یک لحظهٔ مشخص را نشان بده؛ از ترکیب چند زمان یا چند قاب در یک تصویر پرهیز کن. سارا در همهٔ صحنه‌ها همان چهره، سن، مو و لباس مرجع را دارد.

## صحنهٔ ۱ — دیدن خطا

**جملهٔ دقیق داستان:**
> Sara has made a mistake on the first sentence.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Grammar Exceptions”. Show exactly one instant: Sara has made a mistake on the first sentence. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۲ — اصلاح does

**جملهٔ دقیق داستان:**
> She has changed “Does she works?” to “Does she work?”

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Grammar Exceptions”. Show exactly one instant: She has changed “Does she works?” to “Does she work?” Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۳ — مقایسهٔ نمونه‌ها

**جملهٔ دقیق داستان:**
> Her classmates are comparing the corrected examples.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Grammar Exceptions”. Show exactly one instant: Her classmates are comparing the corrected examples. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۴ — خط زمان

**جملهٔ دقیق داستان:**
> One student has gone to the board and drawn a time line.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Grammar Exceptions”. Show exactly one instant: One student has gone to the board and drawn a time line. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۵ — باشگاه گرامر

**جملهٔ دقیق داستان:**
> They have been in the grammar club for a month.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Grammar Exceptions”. Show exactly one instant: They have been in the grammar club for a month. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۶ — یادگیری تفاوت

**جملهٔ دقیق داستان:**
> The group now knows how a small word can change a whole sentence.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Grammar Exceptions”. Show exactly one instant: The group now knows how a small word can change a whole sentence. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.
