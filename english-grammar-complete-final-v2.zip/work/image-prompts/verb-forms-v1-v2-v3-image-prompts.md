# پرامپت‌های تصویر داستان — Verb Forms V1–V2–V3

## شخصیت ثابت

Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration.

## سبک و محدودیت مشترک

تصویرسازی کتاب کودک امروزی، نرم و طبیعی، قاب افقی ۴:۳، بدون متن، عدد، حروف، زیرنویس، لوگو، رابط کاربری یا حباب گفت‌وگو. فقط یک لحظهٔ مشخص را نشان بده؛ از ترکیب چند زمان یا چند قاب در یک تصویر پرهیز کن. سارا در همهٔ صحنه‌ها همان چهره، سن، مو و لباس مرجع را دارد.

## صحنهٔ ۱ — سه ستون فعل

**جملهٔ دقیق داستان:**
> Sara has written the verb cards in three neat columns.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Verb Forms V1–V2–V3”. Show exactly one instant: Sara has written the verb cards in three neat columns. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۲ — انتخاب فعل‌ها

**جملهٔ دقیق داستان:**
> Her team has chosen six verbs for the first round.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Verb Forms V1–V2–V3”. Show exactly one instant: Her team has chosen six verbs for the first round. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۳ — کارت take

**جملهٔ دقیق داستان:**
> Last week, she took a card and went to the front of the class.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Verb Forms V1–V2–V3”. Show exactly one instant: Last week, she took a card and went to the front of the class. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۴ — گفتن شکل‌ها

**جملهٔ دقیق داستان:**
> She spoke the base form, and her partner said the past form.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Verb Forms V1–V2–V3”. Show exactly one instant: She spoke the base form, and her partner said the past form. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۵ — یادگیری الگوها

**جملهٔ دقیق داستان:**
> Everyone has learned a new pattern from the game.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Verb Forms V1–V2–V3”. Show exactly one instant: Everyone has learned a new pattern from the game. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۶ — نوشتن جمله

**جملهٔ دقیق داستان:**
> Before they leave, they write one sentence for every verb.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Verb Forms V1–V2–V3”. Show exactly one instant: Before they leave, they write one sentence for every verb. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.
