# پرامپت‌های تصویر داستان — Present Perfect

## شخصیت ثابت

Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration.

## سبک و محدودیت مشترک

تصویرسازی کتاب کودک امروزی، نرم و طبیعی، قاب افقی ۴:۳، بدون متن، عدد، حروف، زیرنویس، لوگو، رابط کاربری یا حباب گفت‌وگو. فقط یک لحظهٔ مشخص را نشان بده؛ از ترکیب چند زمان یا چند قاب در یک تصویر پرهیز کن. سارا در همهٔ صحنه‌ها همان چهره، سن، مو و لباس مرجع را دارد.

## صحنهٔ ۱ — کاشت گل‌ها

**جملهٔ دقیق داستان:**
> Sara has planted twelve small flowers in the community garden.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Perfect”. Show exactly one instant: Sara has planted twelve small flowers in the community garden. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۲ — ادامهٔ کار از بهار

**جملهٔ دقیق داستان:**
> She has worked there since April.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Perfect”. Show exactly one instant: She has worked there since April. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۳ — نیمکت چوبی

**جملهٔ دقیق داستان:**
> Her class has built a wooden bench near the gate.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Perfect”. Show exactly one instant: Her class has built a wooden bench near the gate. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۴ — بیرون رفتن پس از باران

**جملهٔ دقیق داستان:**
> The rain has stopped, so the children have gone outside.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Perfect”. Show exactly one instant: The rain has stopped, so the children have gone outside. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۵ — بازگشت از انبار

**جملهٔ دقیق داستان:**
> Sara has been to the tool shed and has returned with a watering can.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Perfect”. Show exactly one instant: Sara has been to the tool shed and has returned with a watering can. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.

## صحنهٔ ۶ — پایان باغچه

**جملهٔ دقیق داستان:**
> At the end of the day, they have finished their first garden bed.

**پرامپت تصویر:**
Use the supplied Sara reference illustration for character identity and appearance only. Create one standalone, warm contemporary children’s-book illustration for the English-learning page “Present Perfect”. Show exactly one instant: At the end of the day, they have finished their first garden bed. Sara is the only recurring character in focus; Sara, a 16-year-old Iranian student with warm brown skin, large brown eyes, and thick shoulder-length curly dark hair. She always wears the same teal cardigan over a cream shirt, navy trousers, and a small red backpack. Keep her face, age, hair, body proportions, and clothing consistent with the supplied reference illustration. The scene must depict that one sentence, with a natural school/community setting and clear body language. Landscape 4:3 composition, gentle daylight, soft painterly digital illustration, polished but not photorealistic. No text, letters, numbers, captions, logos, watermarks, signs, UI, panels, collage, or speech bubbles.
