#!/usr/bin/env python3
"""Create a deterministic generation plan from the lesson audio manifest.
This script does not embed a vendor API key. Feed `generation-plan.jsonl` to the TTS/AI generator you choose.
"""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'present-perfect.audio.json').read_text(encoding='utf-8'))
out=ROOT/'generation-plan.jsonl'
with out.open('w',encoding='utf-8') as f:
    for x in m['items']:
        row={
            'id':x['id'],
            'text':x['text'],
            'output_file':'audio/'+x['file'],
            'format':x['format'],
            'bitrateKbps':x['bitrateKbps'],
            'sampleRateHz':x['sampleRateHz'],
            'channels':x['channels'],
            'voice':x['voice'],
        }
        f.write(json.dumps(row,ensure_ascii=False)+'\n')
print(f'Wrote {out} with {len(m["items"])} items')
