# Present Perfect Interactive FA v1

Files:
- Present_Perfect_Interactive_FA_v1.html
- present-perfect.audio.json
- audio_batch_plan.py

## Run locally
python3 -m http.server 8765 --directory .
Open http://127.0.0.1:8765/Present_Perfect_Interactive_FA_v1.html

## Audio design
Runtime does NOT use browser TTS. HTML fetches `present-perfect.audio.json`, downloads MP3 files, caches them via Cache Storage, then plays them.

The current ParsPack remoteBaseUrl in JSON is marked NEEDS_CONFIRMATION. Change only `remoteBaseUrl` after confirming the exact bucket path.

Recommended speech profile: MP3, mono, 44.1 kHz, 64 kbps.
